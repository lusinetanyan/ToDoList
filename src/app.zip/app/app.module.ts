import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { InputComponent } from './input/input.component';
import { TextComponent } from './text/text.component';
import { FilterPipe } from './filter.pipe';
import { CommentComponent } from './comment/comment.component';
import { CommentFilterPipe } from './comment-filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    InputComponent,
    TextComponent,
    FilterPipe,
    CommentComponent,
    CommentFilterPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
