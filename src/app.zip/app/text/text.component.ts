import {Component, Input, OnChanges, SimpleChanges} from '@angular/core';
import {BindingService} from "../binding.service";
import {CommentComponent} from "../comment/comment.component";

@Component({
  selector: 'app-text',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.css']
})
export class TextComponent {

  public count : number = 0;
  input: string[] = BindingService.input;
  checked: boolean[] = BindingService.checked;
  comments: string[][] = BindingService.comments;
  @Input() clicked : boolean = false;

  constructor() { }

  checkboxCount(checked: boolean, index: number) : void {
    if(checked) this.count++;
    else this.count--;
    this.checked[index] = checked;
  }

  labelOnClick(index: number) : void {
    BindingService.commentOn[index] = !BindingService.commentOn[index];
    if(BindingService.commentOn[index]) {
      let comment: CommentComponent = new CommentComponent();
      // @ts-ignore
      document.getElementById('textAndComment').append(comment);
    }
    else {
      // @ts-ignore
      document.getElementById('comment').remove();
    }
  }

  delete(index: number) {
    let i : number = 0;
    let newInput : string[] = [];
    for(let string of this.input) {
      if(i == index) continue;
      newInput.push(string);
      i++;
    }
    this.input = newInput;
  }
}
