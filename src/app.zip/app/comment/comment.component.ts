import {Component, Inject, Input, OnInit} from '@angular/core';
import {BindingService} from "../binding.service";

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {
  public comments : string[] = [];
  public commentOn : boolean = false;

//  constructor (index: number) {
//    this.comments = BindingService.comments[index];
//    this.commentOn = BindingService.commentOn[index];
//  }

  constructor() {
  }

  ngOnInit(): void {
  }

  clickOnComment() {
    const element = document.getElementById('comment');
    // @ts-ignore
    this.comments.push(element.value);
    // @ts-ignore
    element.value = '';
  }

}
