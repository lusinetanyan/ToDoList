import { CommentFilterPipe } from './comment-filter.pipe';

describe('CommentFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CommentFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
